<header>
			
		  <div class="row">	
		  <div class="ten columns centered">
		  <div class="row">
		  
		  <div class="two columns phone-two">
		    <a href="/" class="nav-logo">BoxPay</a>
		  </div>

		  <div class="ten columns phone-two">
		  
		  
		  
		    <nav id="menu" role="navigation" class="hide-for-small">
    			<ul id="mainNav" class="nav-bar">
    					<li class="has-flyout">
    						<a href="#">Product</a>
    						<a href="#" class="flyout-toggle"></a>
    						<ul class="flyout">
    						      <li class="countries"><a href="/countries.php">Countries</a></li>
    						      <li class="features"><a href="/features.php">Features</a></li>
    						      <li class="tablet"><a href="/browser-and-tablet.php">Browser &amp; Tablet</a></li>
    						      <li class="mobile"><a href="/mobile-optimized.php">Mobile Optimized</a></li>
    						      <li class="in-app"><a href="/in-app.php">In-App</a></li>
    						      <li class="smart-tv"><a href="/smart-tv.php">Smart TV</a></li>
    						      <li class="white-label"><a href="/white-label.php">White Label &amp; API</a></li>
    						      <li class="subscription"><a href="/subscription.php">Subscription</a></li>
    						 </ul>	
    					
    					</li>
    					
    					
    					
    					<li><a href="/about.php">About</a></li>
    					<li><a href="php/docs/getting-started.php">Developers</a></li>
    					
    					
    					<li class="has-flyout">
    						<a href="#">FAQ</a>
    						<a href="#" class="flyout-toggle"></a>
    						<ul class="flyout">
    						      <li><a href="/merchant-faq.php">Merchant FAQ</a></li>
    						      <li><a href="/customer-faq.php">Customer FAQ</a></li>
    						 </ul>	
    					</li>
    					
    					
    					
    					
    					<li><a href="http://boxpayblog.com">Blog</a></li>
    		
    		
    		<!-- - - - - - - - NOT SIGNED IN - - - - - - - -->	
        		
    		 <li class="login"><a href="/Account/Logon">Login</a> <span>or</span> <a href="/Merchant-Registration">Sign Up</a></li>			
    					
    			
    			
    		<!-- - - - - - - - SIGNED IN - - - - - - -  -->			
    			
    					
    					<!--<li class="logged-in has-flyout">
    						<a href="#">Signed In</a>
    						<a href="#" class="flyout-toggle"></a>
    						
    						<ul class="flyout">
    						      <li><span>address@aislinnkelly.com</span></li>
    						      <li><span>Merchant ID: 2342</span></li>
    						      
    						 </ul>	
    					</li>	
    					
    					
    					<li class="login"><a href="/sign-out.php">Sign Out</a></li>	-->
    					
    		<!-- - - - - - - - END - - - - - - - -->		
    				
    				
    				
    				
    							
    			</ul>											
    		</nav>
    		
  			<p class="show-for-small">
  			  <a class='sidebar-button button right' id="sidebarButton" href="#sidebar" >Menu</a>
  			</p> 
		  
		  </div>
		  
		  
		  
		  </div>
		  </div> 
		  </div>	
</header>


