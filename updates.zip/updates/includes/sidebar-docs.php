<ul class="no-bullet documentation-nav nav-bar vertical flyout">
	<li class="has-flyout">
		<a>Getting Started</a>
		<a href="#" class="flyout-toggle"></a>
		<ul class="flyout">
			<li class="doc-start"><a href="/docs/getting-started.php">Using the Self Service Widget</a></li>

		</ul>
	</li>
	

		

		<li class="has-flyout">
			<a>Android Billing</a>
			<a href="#" class="flyout-toggle"></a>
			<ul class="flyout">
				<li class="doc-in-app"><a href="/docs/android-billing-sdk-documentation.php">SDK for In-App Billing</a></li>

			</ul>
		</li>
		
		
		
		
		<li class="has-flyout">
			<a>White Label &amp; API</a>
			<a href="#" class="flyout-toggle"></a>
			<ul class="flyout">
				<li class="doc-css"><a href="/docs/css-override-documentation.php">CSS Override / White label</a></li>
				<li class="doc-merch"><a href="/docs/merchant-api-documentation.php">Merchant API</a></li>
				<li class="doc-core"><a href="/docs/core-api-documentation.php">Core API</a></li>
		
			</ul>
		</li>
		

</ul>
